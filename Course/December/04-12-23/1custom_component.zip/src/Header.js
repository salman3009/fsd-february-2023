

function Header(){
    return(<div>
        <h1>Header component</h1>
    </div>)
}

export default Header;