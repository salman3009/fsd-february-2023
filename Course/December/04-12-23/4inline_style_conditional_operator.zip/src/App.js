import './App.css';
import Product from './Product';
function App() {
  return (
    <div className="App">
      <Product name="samsung" price="200"/>
    </div>
  );
}

export default App;
