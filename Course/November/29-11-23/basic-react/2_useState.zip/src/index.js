import React from 'react';
import ReactDOM from 'react-dom/client';
import Employee from './App';
//Employee is the component name 
//App is the file name

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <Employee/>
);


